const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');

router.get('/statistics', async (req, res) => {
  const { month } = req.query;
  if (!month) {
    return res.status(400).send({ error: 'Month is required' });
  }

  const regex = new RegExp(`-${month.padStart(2, '0')}-`);

  const totalSales = await Transaction.aggregate([
    { $match: { dateOfSale: regex } },
    { $group: { _id: null, total: { $sum: '$price' } } },
  ]);

  const totalSoldItems = await Transaction.countDocuments({ dateOfSale: regex, sold: true });
  const totalNotSoldItems = await Transaction.countDocuments({ dateOfSale: regex, sold: false });

  res.send({
    totalSales: totalSales[0] ? totalSales[0].total : 0,
    totalSoldItems,
    totalNotSoldItems,
  });
});

module.exports = router;
