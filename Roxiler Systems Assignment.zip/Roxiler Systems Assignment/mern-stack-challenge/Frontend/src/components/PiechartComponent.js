const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');

router.get('/pie-chart', async (req, res) => {
  const { month } = req.query;
  if (!month) {
    return res.status(400).send({ error: 'Month is required' });
  }

  const regex = new RegExp(`-${month.padStart(2, '0')}-`);

  const categories = await Transaction.aggregate([
    { $match: { dateOfSale: regex } },
    { $group: { _id: '$category', count: { $sum: 1 } } },
  ]);

  res.send(categories.map(category => ({
    category: category._id,
    count: category.count,
  })));
});

module.exports = router;
