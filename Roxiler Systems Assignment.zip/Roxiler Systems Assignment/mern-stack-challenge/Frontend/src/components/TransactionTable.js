const express = require('express');
const router = express.Router();
const Transaction = require('../models/Transaction');
const axios = require('axios');

// Seed database
router.get('/seed', async (req, res) => {
  try {
    const response = await axios.get('https://s3.amazonaws.com/roxiler.com/product_transaction.json');
    await Transaction.deleteMany({});
    await Transaction.insertMany(response.data);
    res.send({ message: 'Database seeded successfully' });
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

// List transactions with search and pagination
router.get('/', async (req, res) => {
  const { page = 1, perPage = 10, search = '', month } = req.query;
  const query = {};

  if (month) {
    query.dateOfSale = { $regex: `-${month.padStart(2, '0')}-` };
  }

  if (search) {
    query.$or = [
      { title: new RegExp(search, 'i') },
      { description: new RegExp(search, 'i') },
      { price: Number(search) || null },
    ];
  }

  const transactions = await Transaction.find(query)
    .skip((page - 1) * perPage)
    .limit(Number(perPage));

  const total = await Transaction.countDocuments(query);

  res.send({ transactions, total });
});

module.exports = router;
