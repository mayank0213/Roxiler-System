const express = require('express');
const router = express.Router();
const axios = require('axios');

router.get('/combined', async (req, res) => {
  try {
    const { month } = req.query;
    const [transactions, statistics, barChart, pieChart] = await Promise.all([
      axios.get(`http://localhost:5000/transactions`, { params: { month } }),
      axios.get(`http://localhost:5000/statistics`, { params: { month } }),
      axios.get(`http://localhost:5000/bar-chart`, { params: { month } }),
      axios.get(`http://localhost:5000/pie-chart`, { params: { month } }),
    ]);

    res.send({
      transactions: transactions.data,
      statistics: statistics.data,
      barChart: barChart.data,
      pieChart: pieChart.data,
    });
  } catch (error) {
    res.status(500).send({ error: error.message });
  }
});

module.exports = router;
